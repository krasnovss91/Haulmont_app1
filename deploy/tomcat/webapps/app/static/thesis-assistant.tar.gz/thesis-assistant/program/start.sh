#!/bin/bash
updateIcon="No"
if type -p nautilus  
then
    if [ ! -f "$HOME/.haulmont/thesis-assistant/iconSet" ]
    then 
        updateIcon="Yes"
    fi
elif [ -f /usr/bin/nautilus ]
then
    if [ ! -f "$HOME/.haulmont/thesis-assistant/iconSet" ]
    then 
        updateIcon="Yes"
    fi
fi
if [ "$updateIcon" = "Yes" ]
then
  fileName="$HOME/.local/share/nautilus/scripts/Send to Thesis"
  fileNameG2="$HOME/.gnome2/nautilus-scripts/Send to Thesis"
  if [ "$LANGUAGE" = "ru" ]
  then
    fileNameG2="$HOME/.gnome2/nautilus-scripts/Отправить в ТЕЗИС"
    fileName="$HOME/.local/share/nautilus/scripts/Отправить в ТЕЗИС"
  fi  
  if [ -f "$fileName" ]
  then
    gvfs-set-attribute -t string "$fileName" metadata::custom-icon "file:///usr/share/pixmaps/thesis_main-16.png"
    if [ -d "$HOME/.haulmont/thesis-assistant" ]
    then
      echo "Yes">"$HOME/.haulmont/thesis-assistant/iconSet"
    fi
  elif [ -f "$fileNameG2" ]
  then
    gvfs-set-attribute -t string "$fileNameG2" metadata::custom-icon "file:///usr/share/pixmaps/thesis_main-16.png"
    if [ -d "$HOME/.haulmont/thesis-assistant" ]
    then
      echo "Yes">"$HOME/.haulmont/thesis-assistant/iconSet"
    fi
  fi
fi

cd /usr/share/haulmont/thesis-assistant
exec java -Xmx110m -XX:+UseCodeCacheFlushing -XX:MaxPermSize=52m -jar ./assistant.jar
